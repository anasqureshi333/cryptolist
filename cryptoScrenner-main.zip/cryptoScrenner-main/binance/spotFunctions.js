const mongoose = require("mongoose");
const Binance = require("node-binance-api");
const Crypto = require("../mongo").Spot

const username = 'quick10x';
const password = encodeURIComponent('HZWX@xM3#mlW');
const connectionString = `mongodb://${username}:${password}@127.0.0.1:27017/?directConnection=true&serverSelectionTimeoutMS=2000&authSource=admin&appName=mongosh+1.10.4`;

mongoose
  .connect(connectionString, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    console.log("The connection to the database was successful");
  })
  .catch((err) => {
    console.error("There was an error trying to connect to the database:", err);
  });

async function getTop10Winners(seconds) {
  const currentTime = new Date();
  const oneDayAgo = new Date(currentTime.getTime() - seconds * 1000);

  const cryptos = await Crypto.find({
    timestamp: {
      $gte: oneDayAgo,
      $lte: currentTime,
    },
  });

  const cryptoGroups = {};
  cryptos.forEach((crypto) => {
    if (!cryptoGroups[crypto.symbol]) {
      cryptoGroups[crypto.symbol] = [];
    }
    cryptoGroups[crypto.symbol].push(crypto);
  });

  const result = [];
  for (const symbol in cryptoGroups) {
    const group = cryptoGroups[symbol].sort(
      (a, b) => new Date(a.timestamp) - new Date(b.timestamp)
    );
    const initialPrice = group[0].price;
    const finalPrice = group[group.length - 1].price;
    const pricePercent =
      finalPrice === initialPrice
        ? 0
        : ((finalPrice - initialPrice) / initialPrice) * 100;

    const initialVol = group[0].vol24;
    const finalVol = group[group.length - 1].vol24;
    const volPercent = ((finalVol - initialVol) / initialVol) * 100;

    const price24hPercent = group[group.length - 1].price24h;
    const vol24h = group[group.length - 1].vol24;

    result.push({
      symbol,
      pricePercent,
      price24hPercent,
      volPercent,
      vol24h,
    });
  }

  const top10Gainers = result
    .sort((a, b) => b.pricePercent - a.pricePercent)
    .slice(0, 10);
  return top10Gainers;
}
async function getTop10Losers(seconds) {
  const currentTime = new Date();
  const oneDayAgo = new Date(currentTime.getTime() - seconds * 1000);

  const cryptos = await Crypto.find({
    timestamp: {
      $gte: oneDayAgo,
      $lte: currentTime,
    },
  });
  const cryptoGroups = {};
  cryptos.forEach((crypto) => {
    if (!cryptoGroups[crypto.symbol]) {
      cryptoGroups[crypto.symbol] = [];
    }
    cryptoGroups[crypto.symbol].push(crypto);
  });

  const result = [];
  for (const symbol in cryptoGroups) {
    const group = cryptoGroups[symbol].sort(
      (a, b) => new Date(a.timestamp) - new Date(b.timestamp)
    );
    const initialPrice = group[0].price;
    const finalPrice = group[group.length - 1].price;
    const pricePercent =
      finalPrice === initialPrice
        ? 0
        : ((finalPrice - initialPrice) / initialPrice) * 100;

    const initialVol = group[0].vol24;
    const finalVol = group[group.length - 1].vol24;
    const volPercent = ((finalVol - initialVol) / initialVol) * 100;

    const price24hPercent = group[group.length - 1].price24h;
    const vol24h = group[group.length - 1].vol24;

    result.push({
      symbol,
      pricePercent,
      price24hPercent,
      volPercent,
      vol24h,
    });
  }

  const top10Losers = result
    .sort((a, b) => a.pricePercent - b.pricePercent)
    .slice(0, 10);
  return top10Losers;
}
async function getTop10VolGainers(seconds) {
  const currentTime = new Date();
  const oneDayAgo = new Date(currentTime.getTime() - seconds * 1000);

  const cryptos = await Crypto.find({
    timestamp: {
      $gte: oneDayAgo,
      $lte: currentTime,
    },
  });

  const cryptoGroups = {};
  cryptos.forEach((crypto) => {
    if (!cryptoGroups[crypto.symbol]) {
      cryptoGroups[crypto.symbol] = [];
    }
    cryptoGroups[crypto.symbol].push(crypto);
  });

  const result = [];
  for (const symbol in cryptoGroups) {
    const group = cryptoGroups[symbol].sort(
      (a, b) => new Date(a.timestamp) - new Date(b.timestamp)
    );
    const initialVol = group[0].vol24;
    const finalVol = group[group.length - 1].vol24;
    const volPercent = ((finalVol - initialVol) / initialVol) * 100;
    const initialPrice = group[0].price;
    const finalPrice = group[group.length - 1].price;
    const pricePercent =
      finalPrice === initialPrice
        ? 0
        : ((finalPrice - initialPrice) / initialPrice) * 100;
    const price24hPercent = group[group.length - 1].price24h;
    const vol24h = group[group.length - 1].vol24;

    result.push({
      symbol,
      volPercent,
      price24hPercent,
      vol24h,
      pricePercent
    });
  }

  const top10VolGainers = result
    .sort((a, b) => b.volPercent - a.volPercent) 
    .slice(0, 10);
  return top10VolGainers; 
}

module.exports = {
  getTop10Winners,
  getTop10Losers,
  getTop10VolGainers,
};
