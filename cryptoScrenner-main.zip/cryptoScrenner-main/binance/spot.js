const mongoose = require("mongoose");
const axios = require("axios");
const Crypto = require("../mongo").Spot
const username = 'quick10x';
const password = encodeURIComponent('HZWX@xM3#mlW');
const connectionString = `mongodb://${username}:${password}@127.0.0.1:27017/?directConnection=true&serverSelectionTimeoutMS=2000&authSource=admin&appName=mongosh+1.10.4`;

mongoose
  .connect(connectionString, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    console.log("The connection to the database was successful");
  })
  .catch((err) => {
    console.error("There was an error trying to connect to the database:", err);
  });

const fetchAndSavePrices = async () => {
  try {
    const response = await axios.get(
      "https://api.binance.com/api/v3/ticker/24hr"
    );
    const spotWithPrices = response.data;
    const timestamp = new Date();
    const documents = spotWithPrices
      .filter((item) => item.symbol.endsWith("USDT"))
      .map((item) => ({
        timestamp,
        symbol: item.symbol,
        price: parseFloat(item.lastPrice),
        price24h: parseFloat(item.priceChangePercent),
        vol24: parseFloat(item.quoteVolume),
      }));
    await Crypto.insertMany(documents);
    console.log("Data insertion was Successful");
  } catch (error) {
    console.error("There was an error trying to get the data:", error);
  }
};

  setInterval(fetchAndSavePrices, 25000);

