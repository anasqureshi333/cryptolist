const mongoose = require("mongoose");
const Binance = require("node-binance-api");
const Crypto = require("../mongo").Futures
const binance = new Binance().options({
  APIKEY: process.env.BINANCE_KEY,
  APISECRET: process.env.BINANCE_SECRET,
});
// Conectar a MongoDB
const username = 'quick10x';
const password = encodeURIComponent('HZWX@xM3#mlW');
const connectionString = `mongodb://${username}:${password}@127.0.0.1:27017/?directConnection=true&serverSelectionTimeoutMS=2000&authSource=admin&appName=mongosh+1.10.4`;

mongoose
  .connect(connectionString, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    console.log("The connection to the database was successful");
  })
  .catch((err) => {
    console.error("There was an error trying to connect to the database:", err);
  });
// Función para obtener precios y insertar en MongoDB
const fetchAndSavePrices = async () => {
  try {
    const futuresPrices = await binance.futuresDaily();
    const timestamp = new Date();
    const documents = Object.entries(futuresPrices)
      .filter(([symbol]) => symbol.endsWith("USDT")) // Filtrar solo pares que terminan en 'USDT'
      .map(([symbol, data]) => ({
        timestamp,
        symbol,
        price: parseFloat(data.lastPrice),
        price24h: parseFloat(data.priceChangePercent),
        vol24: parseFloat(data.quoteVolume),
      }));
    await Crypto.insertMany(documents);
    console.log("Data insertion was Successful");
  } catch (error) {
    console.error("There was an error trying to get the data:", error);
  }
};

  setInterval(fetchAndSavePrices,  25000);

