-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 21-08-2023 a las 23:43:53
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `quick10x`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `coinpayments_ipn`
--

CREATE TABLE `coinpayments_ipn` (
  `id` varchar(300) NOT NULL,
  `ipn_id` text NOT NULL,
  `currency` varchar(120) NOT NULL,
  `item_name` varchar(120) NOT NULL,
  `email` varchar(256) NOT NULL,
  `status` int(11) NOT NULL,
  `status_text` text NOT NULL,
  `username` varchar(256) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `amount` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `coupons_generated`
--

CREATE TABLE `coupons_generated` (
  `coupon_id` int(11) NOT NULL,
  `coupon` text NOT NULL,
  `generated_by_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `login_history`
--

CREATE TABLE `login_history` (
  `id` int(11) NOT NULL,
  `ip` text NOT NULL,
  `username` varchar(200) NOT NULL,
  `logged_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `master_coupon`
--

CREATE TABLE `master_coupon` (
  `id` int(11) NOT NULL,
  `coupon` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `payouts`
--

CREATE TABLE `payouts` (
  `id` int(11) NOT NULL,
  `state` varchar(255) DEFAULT 'pending',
  `amount` float NOT NULL,
  `user_id` int(11) NOT NULL,
  `refered_user` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `revenue`
--

CREATE TABLE `revenue` (
  `total` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `special_user`
--

CREATE TABLE `special_user` (
  `id` int(11) NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `special_user`
--

INSERT INTO `special_user` (`id`, `email`, `password`) VALUES
(2, 'admin@admin.com', '$2b$10$XUTshWh0saDELWNgqYKk4ujxl37GNRLTvHkY7RlXMVlVG6kU8/toW');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `stripe_subscriptions`
--

CREATE TABLE `stripe_subscriptions` (
  `id` varchar(500) NOT NULL,
  `created` date NOT NULL,
  `start_period` date NOT NULL,
  `end_period` date NOT NULL,
  `customer_id` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `stripe_transactions`
--

CREATE TABLE `stripe_transactions` (
  `id` varchar(600) NOT NULL,
  `created` date NOT NULL,
  `customer` varchar(200) NOT NULL,
  `customer_email` varchar(256) NOT NULL,
  `customer_name` varchar(150) NOT NULL,
  `customer_username` varchar(200) DEFAULT NULL,
  `subscription` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `subscriptions`
--

CREATE TABLE `subscriptions` (
  `subscription_id` int(11) NOT NULL,
  `subscription_name` varchar(200) NOT NULL,
  `subscription_price` decimal(10,2) NOT NULL,
  `subscription_stripe_code` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `username` varchar(50) NOT NULL,
  `creation_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `UUID` text NOT NULL,
  `is_loggeable` tinyint(1) NOT NULL DEFAULT 0,
  `trc20_address` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users_discount`
--

CREATE TABLE `users_discount` (
  `user_discount_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `stripe_coupon_5` text NOT NULL,
  `stripe_coupon_10` text NOT NULL,
  `stripe_coupon_15` text NOT NULL,
  `master_discount` tinyint(1) NOT NULL DEFAULT 0,
  `used_coupon` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users_subscriptions`
--

CREATE TABLE `users_subscriptions` (
  `users_subscriptions_id` int(11) NOT NULL,
  `subscription_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `subscription_start_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `stripe_customer_id` varchar(255) DEFAULT NULL,
  `coin_ipn` text DEFAULT NULL,
  `end_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Disparadores `users_subscriptions`
--
DELIMITER $$
CREATE TRIGGER `update_revenue` AFTER INSERT ON `users_subscriptions` FOR EACH ROW BEGIN
  DECLARE price DECIMAL(10, 2);

  -- Obtener el precio de la suscripción usando el subscription_id de la tabla users_subscriptions
  SELECT subscription_price INTO price FROM subscriptions WHERE subscription_id = NEW.subscription_id;

  -- Actualizar el ingreso total en la tabla revenue
  UPDATE revenue SET total = total + price;
END
$$
DELIMITER ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `coinpayments_ipn`
--
ALTER TABLE `coinpayments_ipn`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `coupons_generated`
--
ALTER TABLE `coupons_generated`
  ADD PRIMARY KEY (`coupon_id`),
  ADD UNIQUE KEY `unique_generated_by_user` (`generated_by_user`);

--
-- Indices de la tabla `login_history`
--
ALTER TABLE `login_history`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `master_coupon`
--
ALTER TABLE `master_coupon`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `payouts`
--
ALTER TABLE `payouts`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `special_user`
--
ALTER TABLE `special_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`) USING HASH,
  ADD UNIQUE KEY `email_2` (`email`) USING HASH;

--
-- Indices de la tabla `stripe_subscriptions`
--
ALTER TABLE `stripe_subscriptions`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `stripe_transactions`
--
ALTER TABLE `stripe_transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `subscriptions`
--
ALTER TABLE `subscriptions`
  ADD PRIMARY KEY (`subscription_id`),
  ADD UNIQUE KEY `subscription_stripe_code` (`subscription_stripe_code`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indices de la tabla `users_discount`
--
ALTER TABLE `users_discount`
  ADD PRIMARY KEY (`user_discount_id`),
  ADD UNIQUE KEY `unique_user_id_discount` (`user_id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indices de la tabla `users_subscriptions`
--
ALTER TABLE `users_subscriptions`
  ADD PRIMARY KEY (`users_subscriptions_id`),
  ADD UNIQUE KEY `subscription_id` (`subscription_id`,`user_id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `coupons_generated`
--
ALTER TABLE `coupons_generated`
  MODIFY `coupon_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `login_history`
--
ALTER TABLE `login_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `master_coupon`
--
ALTER TABLE `master_coupon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `payouts`
--
ALTER TABLE `payouts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `special_user`
--
ALTER TABLE `special_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `subscriptions`
--
ALTER TABLE `subscriptions`
  MODIFY `subscription_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `users_discount`
--
ALTER TABLE `users_discount`
  MODIFY `user_discount_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `users_subscriptions`
--
ALTER TABLE `users_subscriptions`
  MODIFY `users_subscriptions_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `users_subscriptions`
--
ALTER TABLE `users_subscriptions`
  ADD CONSTRAINT `users_subscriptions_ibfk_1` FOREIGN KEY (`subscription_id`) REFERENCES `subscriptions` (`subscription_id`),
  ADD CONSTRAINT `users_subscriptions_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
