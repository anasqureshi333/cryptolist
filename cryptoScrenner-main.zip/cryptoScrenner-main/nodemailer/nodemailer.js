const nodemailer = require("nodemailer");

const transporter = nodemailer.createTransport({
  host: "smtp-relay.sendinblue.com",
  port: 587,
  secure: false,
  auth: {
    // TODO: replace `user` and `pass` values from <https://forwardemail.net>
    user: "bcdclaunchpass@gmail.com",
    pass: "InvAbfTWVKmFDPOU",
  },
});

// async..await is not allowed in global scope, must use a wrapper
async function sendVerifyEmail(email, uuid) {
  // send mail with defined transport object
  const info = await transporter.sendMail({
    from: '"Quick10x" <noreply@quick10x.com>', // sender address
    to: email, // list of receivers
    subject: "Verify Your Account", // Subject line
    html: `<p>Hello, thanks for sign up in Quick10x, please verify your account clicking on the following link: <link href='${
      "https://quick10x.com/" + "verify-email?uuid=" + uuid
    }'>${"https://quick10x.com/" + "verify-email?uuid=" + uuid}</link></p>`,
  });

  console.log("Message sent: %s", info.messageId);
  // Message sent: <b658f8ca-6296-ccf4-8306-87d57a0b4321@example.com>

  //
  // NOTE: You can go to https://forwardemail.net/my-account/emails to see your email delivery status and preview
  //       Or you can use the "preview-email" npm package to preview emails locally in browsers and iOS Simulator
  //       <https://github.com/forwardemail/preview-email>
  //
}

async function sendPaymentReminder(email, hosted_invoice_url) {
  // send mail with defined transport object
  const info = await transporter.sendMail({
    from: '"Quick10x" <noreply@quick10x.com>', // sender address
    to: email, // list of receivers
    subject: "Payment has failed!", // Subject line
    html: `<p>Hello, your payment has failed, please try again to buy your subscription in the following link: <link href='${hosted_invoice_url}'>${hosted_invoice_url}</link></p>`,
  });
  console.log("Message sent: %s", info.messageId);
}

async function sendPasswordRecovery(email, code) {
  const info = await transporter.sendMail({
    from: '"Quick10x" <noreply@quick10x.com>', // sender address
    to: email, // list of receivers
    subject: "Recover Your Password", // Subject line
    html: `<p>To recover Your Password, please use the following Code: ${code}</p>`,
  });
  console.log("Message sent: %s", info.messageId + " verification");
}

async function newContactFormMessage(
  email,
  subject,
  message,
  originalEmail,
  username,
  file
) {
  if (file) {
    const info = await transporter.sendMail({
      from: '"Quick10x - Contact" <noreplay@quick10x.com>"', // sender address
      to: "info@quick10x.com",
      subject:
        subject + " from " + email + " at " + new Date().toLocaleString(),
      html: `
      You have a new message from the contact form:
      <br>
      <br>
      <strong>Original email:</strong> ${originalEmail}
      <strong>reply to:</strong> ${email || "original email"}
      <strong>Username:</strong> ${username}
      <br>
      <br>
      <strong>Subject:</strong> ${subject}
      <br>
      <br>
      <strong>Message:</strong> ${message}
      `,
      attachments: [
        {
          filename: file.name,
          path: file.path,
          contentType: file.mimetype,

        },
      ],
    });
    return  console.log("Message sent: %s", info.messageId + " contact form file");
  }
  console.log(file)
  const info = await transporter.sendMail({
    from: '"Quick10x - Contact" <noreplay@quick10x.com>"', // sender address
    to: "info@quick10x.com",
    subject: subject + " from " + email + " at " + new Date().toLocaleString(),
    html: `
    You have a new message from the contact form:
    <br>
    <br>
    <strong>Original email:</strong> ${originalEmail}
    <strong>reply to:</strong> ${email || "original email"}
    <strong>Username:</strong> ${username}
    <br>
    <br>
    <strong>Subject:</strong> ${subject}
    <br>
    <br>
    <strong>Message:</strong> ${message}
    `,
  });
  console.log("Message sent: %s", info.messageId + " contact form");
}

async function userRequestedPayout(user,amount,trc20){
  const info = await transporter.sendMail({
    from: '"Quick10x - Contact" <noreplay@quick10x.com>"', // sender address
    to: "info@quick10x.com",
    subject: `${user} requested payout`,
    html: `
    NEW PAYOUT REQUEST <br>
    <strong>User:</strong> ${user}
    <br>
    <br>
    <strong>Amount:</strong> ${amount}
    <br>
    <br>
    <strong>TRC20:</strong> ${trc20}
    <br>
    <br>
    <a href="http://quick10x.com/fredrick/users?user=${user}">User Profile</a>
    `,
  });
  console.log("Message sent: %s", info.messageId + " payout request");
}
module.exports = {
  sendVerifyEmail,
  sendPaymentReminder,
  sendPasswordRecovery,
  newContactFormMessage,
  userRequestedPayout
};
