const express = require("express");
const path = require("path");
require("dotenv").config();
const routes = require("./routes/routes");
const app = express();
const port = process.env.PORT || 3003;
const cookieParser = require('cookie-parser');

const bodyParser = require("body-parser")

const cors = require('cors');

// Crea una instancia 

// Habilita CORS para todos los orígenes o específica cuáles quieres permitir
app.use(cors());

app.use(cookieParser());
app.set('trust proxy', 1); // Confía en el primer proxy


app.use((req, res, next) => {
  if (req.path !== '/webhook') {
    bodyParser.json()(req, res, next);
  } else {
    next();
  }
});
app.set('view engine', 'ejs');

app.set('views', path.join(__dirname, 'views'));

app.use(express.static(path.join(__dirname,'public')))

app.use('/static',express.static('public'))

app.use(express.static(path.join(__dirname, 'build')));
app.use(routes);
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'build', 'index.html'));
});

// start server
const server = app.listen(port, () => {
  console.log("Server started on port " + port);
});

module.exports = server;
