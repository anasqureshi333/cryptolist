const mysql = require("../mysql");
const { sendPaymentReminder } = require("../nodemailer/nodemailer");
require("dotenv").config();
function formatDate(timestamp) {
  return new Date(timestamp * 1000).toISOString().slice(0, 10);
}
function insertIntoTransactions({
  id,
  created,
  customer,
  customer_details,
  subscription,
  metadata,
  amount_total,
}) {
  mysql.query("SELECT total FROM revenue", (err, result) => {
    if (err) throw err;
    const total = result[0].total;
    mysql.query(
      "UPDATE revenue SET total =  ?",
      [parseFloat(amount_total / 100) + parseFloat(total)],
      (err, result) => {
        if (err) throw err;
        console.log("1 record inserted or updated");
      }
    );
  });
  const query =
  "INSERT INTO stripe_transactions (id, created, customer, customer_email, customer_name, customer_username, subscription) VALUES (?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE created = VALUES(created), customer = VALUES(customer), customer_email = VALUES(customer_email), customer_name = VALUES(customer_name), customer_username = VALUES(customer_username), subscription = VALUES(subscription)";
  const values = [
    id,
    new Date(created * 1000).toISOString().slice(0, 10),
    customer,
    customer_details.email,
    customer_details.name,
    metadata.username,
    subscription,
  ];
  mysql.query(query, values, (err, result) => {
    if (err) throw err;
    console.log("1 record inserted");
  });
}
function insertIntoSubscriptions(dataObject) {
  const formattedDate = formatDate(dataObject.created);

  mysql.query(
    `SELECT id FROM users WHERE username = ?`,
    [dataObject.metadata.username],
    (err, results, fields) => {
      if (err || results.length === 0) {
        console.error("Error fetching user_id:", err);
        return;
      }

      const userId = results[0].id;
      const secondQuery = `INSERT INTO users_subscriptions (user_id, subscription_id, subscription_start_date,stripe_customer_id) VALUES (?, ?, ?,?)`;

      mysql.query(
        secondQuery,
        [userId, dataObject.metadata.plan, formattedDate, dataObject.customer],
        (err, results, fields) => {
          if (err) {
            console.error("Error inserting into users_subscriptions:", err);
          }
        }
      );
    }
  );
}

function insertIntoPayuouts(usedCoupon, username, plan) {
  return new Promise((resolve, reject) => {
    if (usedCoupon) {
      mysql.query(
        "SELECT * FROM subscriptions WHERE subscription_id = ?",
        [plan],
        (err, results, fields) => {
          if (err) {
            console.log(err);
          }
          if (results.length > 0) {
            switch (results[0].subscription_name) {
              case "Monthly Subscription":
                mysql.query(
                  "INSERT INTO payouts (amount,user_id,refered_user) VALUES (5, (SELECT generated_by_user FROM coupons_generated WHERE coupon=?), (SELECT id FROM users WHERE username = ?))",
                  [usedCoupon, username],
                  (err, results, fields) => {
                    if (err) {
                      console.log(err);
                    }
                    resolve();
                  }
                );
                break;
              case "3 Months Subscription":
                mysql.query(
                  "INSERT INTO payouts (amount,user_id,refered_user) VALUES (10, (SELECT generated_by_user FROM coupons_generated WHERE coupon=?), (SELECT id FROM users WHERE username = ?))",
                  [usedCoupon, username],
                  (err, results, fields) => {
                    if (err) {
                      console.log(err);
                    }
                    resolve();
                  }
                );
                break;
              case "6 Months Subscription":
                mysql.query(
                  "INSERT INTO payouts (amount,user_id,refered_user) VALUES (15, (SELECT generated_by_user FROM coupons_generated WHERE coupon=?), (SELECT id FROM users WHERE username = ?))",
                  [usedCoupon, username],
                  (err, results, fields) => {
                    if (err) {
                      console.log(err);
                    }
                    resolve();
                  }
                );
                break;
            }
          }
        }
      );
    } else {
      reject("No coupon used");
    }
  });
}

async function returnInsertIntoPayouts(param) {
  try {
    const results = await insertIntoPayuouts(
      param.metadata.usedCoupon,
      param.metadata.username,
      param.metadata.plan
    );
    return;
  } catch (err) {
    console.log(err);
    return;
  }
}

function insertIntoStripeSubscriptions({
  id,
  created,
  current_period_start,
  current_period_end,
  customer,
}) {
  const createdDate = formatDate(created);
  const currentPeriodStartDate = formatDate(current_period_start);
  const currentPeriodEndDate = formatDate(current_period_end);
  const values = [
    id,
    createdDate,
    currentPeriodStartDate,
    currentPeriodEndDate,
    customer,
  ];
  const query = `INSERT INTO stripe_subscriptions (id,created,start_period,end_period,customer_id) VALUES (?,?,?,?,?)`;
  mysql.query(query, values, (err, result) => {
    if (err) throw err;
    console.log("1 record inserted");
  });
}

function updateCustomerSubscription({
  id,
  created,
  current_period_start,
  current_period_end,
  customer,
}) {
  const createdDate = formatDate(created);
  const currentPeriodStartDate = formatDate(current_period_start);
  const currentPeriodEndDate = formatDate(current_period_end);
  const values = [
    id,
    createdDate,
    currentPeriodStartDate,
    currentPeriodEndDate,
    customer,
  ];
  const query = `UPDATE stripe_subscriptions SET created = ?,start_period = ?,end_period = ?,customer_id = ? WHERE id = ?`;
  mysql.query(query, values, (err, result) => {
    if (err) throw err;
    console.log("1 record updated");
  });
}

function removeCustomerSubscription({ id, customer }) {
  const values = [id, customer];
  const query = `DELETE FROM stripe_subscriptions WHERE id = ? AND customer_id = ?`;
  mysql.query(query, values, (err, result) => {
    if (err) throw err;
    console.log("1 record deleted");
  });
  const secondQuery =
    "DELETE FROM users_subscriptions WHERE stripe_customer_id = ?";
  mysql.query(secondQuery, [customer], (err, result) => {
    if (err) throw err;
    console.log("1 record deleted");
  });
}

function tellCustomerToPay({ id, customer, hosted_invoice_url }) {
  const query =
    "SELECT email FROM users WHERE username = (SELECT customer_username FROM stripe_transactions WHERE customer = ?)";
  mysql.query(query, [customer], async (err, result) => {
    if (err) throw err;
    console.log("1 record selected");
    const email = result[0].email;
    await sendPaymentReminder(email, hosted_invoice_url);
  });
}

async function removeCustomerSubscriptionManually(username, stripe) {
  try {
    // Query to get Stripe customer ID
    const query =
      "SELECT stripe_customer_id FROM users_subscriptions WHERE user_id = (SELECT id FROM users WHERE username = ?)";
    const [customerResult] = await new Promise((resolve, reject) => {
      mysql.query(query, [username], (err, result) => {
        if (err) reject(err);
        resolve(result);
      });
    });
    // If no Stripe customer ID found, delete the non-Stripe subscription and exit
    if (!customerResult || !customerResult.stripe_customer_id) {
      console.log(
        "No Stripe customer ID found. Deleting non-Stripe subscription."
      );
      const nonStripeDeleteQuery =
        "DELETE FROM users_subscriptions WHERE user_id = (SELECT id FROM users WHERE username = ?)";
      await new Promise((resolve, reject) => {
        mysql.query(nonStripeDeleteQuery, [username], (err) => {
          if (err) reject(err);
          resolve();
        });
      });
      console.log("Non-Stripe subscription deleted");
      return true;
    }
    const customer = customerResult.stripe_customer_id;

    // Delete the user subscription record
    const secondQuery =
      "DELETE FROM users_subscriptions WHERE stripe_customer_id = ?";
    await new Promise((resolve, reject) => {
      mysql.query(secondQuery, [customer], (err) => {
        if (err) reject(err);
        resolve();
      });
    });
    console.log("1 record deleted");

    // Tercera consulta
    const thirdQuery =
      "SELECT id FROM stripe_subscriptions WHERE customer_id = ?";
    const [subscriptionResult] = await new Promise((resolve, reject) => {
      mysql.query(
        thirdQuery,
        [customerResult.stripe_customer_id],
        (err, result) => {
          if (err) reject(err);
          resolve(result);
        }
      );
    });
    if (!subscriptionResult || !subscriptionResult.id) {
      console.log("No se encontró la suscripción");
      return false;
    }
    const id = subscriptionResult.id;

    // Cancelación de suscripción en Stripe
    const deleted = await stripe.subscriptions.cancel(id);
    if (!deleted) {
      console.log("No se pudo cancelar la suscripción en Stripe");
      return false;
    }

    // Cuarta consulta
    const fourthQuery = "DELETE FROM stripe_subscriptions WHERE id = ?";
    await new Promise((resolve, reject) => {
      mysql.query(fourthQuery, [id], (err) => {
        if (err) reject(err);
        resolve();
      });
    });
    console.log("1 record deleted");
    return true;
  } catch (err) {
    console.log("Error en removeCustomerSubscriptionManually:", err);
    return false;
  }
}

const fetchStripeLatestTransactions = () => {
  return new Promise((resolve, reject) => {
    const query =
      "SELECT * FROM stripe_transactions ORDER BY created DESC LIMIT 5";
    mysql.query(query, (err, result) => {
      if (err) {
        console.log(err);
        return reject(err);
      }
      if (result.length > 0) {
        return resolve(result);
      }
      return reject(result.length > 0);
    });
  });
};

const fetchAllStripTransaction = () => {
  return new Promise((resolve, reject) => {
    const query =
      "SELECT * FROM stripe_transactions ORDER BY created DESC";
    mysql.query(query, (err, result) => {
      if (err) {
        console.log(err);
        return reject(err);
      }
      if (result.length > 0) {
        return resolve(result);
      }
      return reject(result.length > 0);
    });
  });
}

async function getLatestTransactions() {
  try {
    const result = await fetchStripeLatestTransactions();
    return result;
  } catch (err) {
    console.log(err);
    return false;
  }
}
module.exports = {
  insertIntoTransactions,
  insertIntoSubscriptions,
  insertIntoStripeSubscriptions,
  updateCustomerSubscription,
  removeCustomerSubscription,
  tellCustomerToPay,
  removeCustomerSubscriptionManually,
  getLatestTransactions,
  returnInsertIntoPayouts,
  fetchAllStripTransaction
  
};
