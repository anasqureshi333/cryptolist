const jwt = require("jsonwebtoken");
const mysql = require("../mysql");
require("dotenv").config();
const checkTokenGET = (req, res, next) => {
  try{
    const token = req.query;
    if (!token || !token.token)
      return res.status(401).send({ msg: "Missing Token" });
  
    jwt.verify(token.token, process.env.SECRET_JWT, (err, user) => {
      if (err) return res.sendStatus(403);
  
      mysql.query(
        "SELECT * FROM users WHERE username = ?",
        [user.username],
        (error, results, fields) => {
          if (error) {
            console.log(error);
            return res.status(500).send({ msg: "500 INTERNAL SERVER ERROR" });
          }
  
          if (results.length > 0) {
            if (results[0].is_loggeable === 0) {
              if(results[0].username !== user.username) return res.status(403).send({msg: 'Token is not valid'})

              return res.status(403).json({ msg: "User is not loggeable" });
            }
            return next();
          } else {
            return res.status(404).json({ msg: "User not found" });
          }
        }
      );
    });
  }catch(err) {console.log(err)}
};

const checkTokenPOST = (req, res, next) => {
  const token = req.body;
  if (!token || !token.token)
    return res.status(401).send({ msg: "Missing Token" });

  jwt.verify(token.token, process.env.SECRET_JWT, (err, user) => {
    if (err) return res.sendStatus(403);

    mysql.query(
      "SELECT * FROM users WHERE username = ?",
      [user.username],
      (error, results, fields) => {
        if (error) {
          console.log(error);
          return res.status(500).send({ msg: "500 INTERNAL SERVER ERROR" });
        }
        if (results.length > 0) {
          if(results[0].username !== user.username) return res.status(403).send({msg: 'Token is not valid'})
          if (results[0].is_loggeable === 0) {
            return res.status(403).json({ msg: "User is not loggeable" });
          }
          return next();
        } else {
          return res.status(404).json({ msg: "User not found" });
        }
      }
    );
  });
};

const checkTokenGETAndUserPremium = (req, res, next) => {
  const { token } = req.query;
  if (!token) return res.status(401).send({ msg: "Missing Token" });

  jwt.verify(token, process.env.SECRET_JWT, (err, user) => {
    if (err) return res.status(403).send(err);

    const query = `SELECT users_subscriptions.user_id, users.is_loggeable
    FROM users_subscriptions
    JOIN users ON users.id = users_subscriptions.user_id
    WHERE users.username = ?;
    `;
    mysql.query(query, [user.username], (error, results, fields) => {
      if (error) {
        console.log(error);
        return res.status(500).send({ msg: "500 INTERNAL SERVER ERROR" });
      }

      if (results.length > 0) {
        if (results[0].is_loggeable === 0) {
          return res.status(403).json({ msg: "User is not loggeable" });
        }
        return next();
      } else {
        return res.status(401).json({ msg: "You need to buy a plan" });
      }
    });
  });
};


const checkTokenPostAndUserPremium = (req, res, next) => {
  const { token } = req.body;
  if (!token) return res.status(401).send({ msg: "Missing Token" });

  jwt.verify(token, process.env.SECRET_JWT, (err, user) => {
    if (err) return res.status(403).send(err);

    const query = `SELECT users_subscriptions.user_id, users.is_loggeable
    FROM users_subscriptions
    JOIN users ON users.id = users_subscriptions.user_id
    WHERE users.username = ?;
    `;
    mysql.query(query, [user.username], (error, results, fields) => {
      if (error) {
        console.log(error);
        return res.status(500).send({ msg: "500 INTERNAL SERVER ERROR" });
      }

      if (results.length > 0) {
        if (results[0].is_loggeable === 0) {
          return res.status(403).json({ msg: "User is not loggeable" });
        }
        return next();
      } else {
        return res.status(401).json({ msg: "You need to buy a plan" });
      }
    });
  });
};

module.exports = {
  checkTokenGET,
  checkTokenPOST,
  checkTokenGETAndUserPremium,
  checkTokenPostAndUserPremium
};
