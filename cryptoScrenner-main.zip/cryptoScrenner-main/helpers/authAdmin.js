const jwt = require("jsonwebtoken");
const mysql = require("../mysql");
require("dotenv").config()
function authenticateUser(req, res, next) {
    try {
      const token = req.cookies.token || req.headers['authorization'].split(' ')[1];
      if (!token) {
        return res.status(401).json({ message: 'ACCESS NOT GRANTED' });
      }
  
      jwt.verify(token, process.env.SECRET_JWT_ADMIN, (err, decoded) => {
        if (err) {
          return res.redirect("/fredrick")
        }
  
        req.user = decoded;
  
        next();
      });
    } catch (err) {
        console.log(err)
      res.status(500).json({ message: 'AUTORIZATION ERROR' });
    }
  }


 module.exports = authenticateUser;
  