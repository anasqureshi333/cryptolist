const mysql = require("../mysql");
require("dotenv").config();
const uuid = require("uuid");
const generateNewCoupon = async (res, user) => {
  // Check if the user already has a coupon
  if (await checkIfUserHasCoupon(user)) {
    return res.status(500).json({ message: "USER ALREADY HAS A COUPON" });
  }

  // Generate a unique coupon
  let couponToInsert;
  do {
    couponToInsert = generateRandomCoupon();
  } while (await checkIfCouponExist(couponToInsert));

  // Query to insert the coupon
  const query =
    "INSERT INTO coupons_generated (coupon, generated_by_user) VALUES (?, (SELECT id FROM users WHERE username = ?))";

  // Execute the query
  mysql.query(query, [couponToInsert, user], (err) => {
    if (err) {
      return res.status(500).json({ message: "INTERNAL SERVER ERROR" });
    }
    res
      .status(200)
      .json({ message: "COUPON GENERATED", coupon: couponToInsert });
  });
};

const checkIfRefferalExistAndAddCoupon = async (coupon, user, stripe) => {
  try {
    let query = "SELECT * FROM coupons_generated WHERE coupon = ?";
    mysql.query(query, [coupon], async (err, rows) => {
      if (err) console.log(err);
      if (rows.length === 0) return;
      const firstCoupon = await stripe.coupons.create({
        duration: "forever",
        id: uuid.v4(),
        amount_off: 500,
        currency: "USD",
      });
      const secondCoupon = await stripe.coupons.create({
        duration: "forever",
        id: uuid.v4(),
        amount_off: 1000,
        currency: "USD",
      });
      const thirdCoupon = await stripe.coupons.create({
        duration: "forever",
        id: uuid.v4(),
        amount_off: 1500,
        currency: "USD",
      });
      const secondQuery =
        "INSERT INTO users_discount (user_id,stripe_coupon_5,stripe_coupon_10,stripe_coupon_15,used_coupon) VALUES ((SELECT id FROM users WHERE username = ?),?,?,?,?)";
      mysql.query(
        secondQuery,
        [user, firstCoupon.id, secondCoupon.id, thirdCoupon.id, coupon],
        (err) => {
          if (err) {
            console.log(err);
          }
        }
      );
    });
  } catch (err) {
    console.log(err);
  }
};

const checkIfCouponIsMasterCoupon = (coupon) => {
  return new Promise((resolve, reject) => {
    const query = "SELECT * FROM master_coupon WHERE coupon = ?";
    mysql.query(query, [coupon], (err, rows) => {
      if (err) {
        return reject(err);
      }
      resolve(rows.length > 0);
    });
  });
};
const checkIfCouponIsFromSameUser = (coupon, user) => {
  return new Promise((resolve, reject) => {
    const query =
      "SELECT * FROM coupons_generated WHERE coupon = ? AND generated_by_user = (SELECT id FROM users WHERE username = ?)";
    mysql.query(query, [coupon, user], (err, rows) => {
      if (err) {
        return reject(err);
      }
      resolve(rows.length > 0);
    });
  });
};

const checkIfRefferalExistAndSendCoupon = async (res, coupon, user, stripe) => {
  try {
    if (await checkIfCouponIsMasterCoupon(coupon)) {
      const firstCoupon = await stripe.coupons.create({
        duration: "forever",
        id: uuid.v4(),
        amount_off: 1000,
        currency: "USD",
      });
      const secondCoupon = await stripe.coupons.create({
        duration: "forever",
        id: uuid.v4(),
        amount_off: 2000,
        currency: "USD",
      });
      const thirdCoupon = await stripe.coupons.create({
        duration: "forever",
        id: uuid.v4(),
        amount_off: 3000,
        currency: "USD",
      });
      const secondQuery =
        "INSERT INTO users_discount (user_id,stripe_coupon_5,stripe_coupon_10,stripe_coupon_15,used_coupon,master_discount) VALUES ((SELECT id FROM users WHERE username = ?),?,?,?,?,1)";
      const result = await new Promise((resolve, reject) => {
        mysql.query(
          secondQuery,
          [user, firstCoupon.id, secondCoupon.id, thirdCoupon.id, coupon, 1],
          (err) => {
            if (err) {
              console.log(err);
              reject(false);
            }
            resolve(true);
          }
        );
      });
      if (result) {
        return res
          .status(200)
          .json({ message: "COUPON REDEEMED SUCCESSFULLY" });
      }
      return res.status(500).json({ message: "INTERNAL SERVER ERROR" });
    }
    if (await checkIfCouponIsFromSameUser(coupon, user)) {
      return res
        .status(500)
        .json({ message: "YOU CAN'T REDEEM YOUR OWN COUPON" });
    }
    const query = "SELECT * FROM coupons_generated WHERE coupon = ?";
    mysql.query(query, [coupon], async (err, rows) => {
      if (err) {
        console.log(err);
        return res.status(500).json({ message: "INTERNAL SERVER ERROR" });
      }
      if (rows.length === 0) {
        return res.status(500).json({ message: "COUPON NOT VALID" });
      } else {
        const firstCoupon = await stripe.coupons.create({
          duration: "forever",
          id: uuid.v4(),
          amount_off: 500,
          currency: "USD",
        });
        const secondCoupon = await stripe.coupons.create({
          duration: "forever",
          id: uuid.v4(),
          amount_off: 1000,
          currency: "USD",
        });
        const thirdCoupon = await stripe.coupons.create({
          duration: "forever",
          id: uuid.v4(),
          amount_off: 1500,
          currency: "USD",
        });
        const secondQuery =
          "INSERT INTO users_discount (user_id,stripe_coupon_5,stripe_coupon_10,stripe_coupon_15,used_coupon) VALUES ((SELECT id FROM users WHERE username = ?),?,?,?,?)";
        mysql.query(
          secondQuery,
          [user, firstCoupon.id, secondCoupon.id, thirdCoupon.id, coupon],
          (err) => {
            if (err) {
              console.log(err);
              return res.status(500).json({ message: "INTERNAL SERVER ERROR" });
            }
            return res
              .status(200)
              .json({ message: "COUPON REDEEMED SUCCESSFULLY" });
          }
        );
      }
    });
  } catch (err) {
    console.log(err);
  }
};

// Function to check if a user already has a coupon
const checkIfUserHasCoupon = (user) => {
  return new Promise((resolve, reject) => {
    const query =
      "SELECT * FROM coupons_generated WHERE generated_by_user = (SELECT id FROM users WHERE username = ?)";

    mysql.query(query, [user], (err, rows) => {
      if (err) {
        return reject(err);
      }

      resolve(rows.length > 0);
    });
  });
};

// Function to check if a coupon already exists
const checkIfCouponExist = (coupon) => {
  return new Promise((resolve, reject) => {
    const query = "SELECT * FROM coupons_generated WHERE coupon = ?";

    mysql.query(query, [coupon], (err, rows) => {
      if (err) {
        return reject(err);
      }

      resolve(rows.length > 0);
    });
  });
};

// Function to generate a random coupon code
const generateRandomCoupon = () => {
  const characters =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  let coupon = "";

  for (let i = 0; i < 10; i++) {
    // 10 is the desired length of the coupon
    const randomIndex = Math.floor(Math.random() * characters.length);
    coupon += characters.charAt(randomIndex);
  }

  return coupon;
};

module.exports = {
  generateNewCoupon,
  checkIfRefferalExistAndSendCoupon,
  checkIfRefferalExistAndAddCoupon,
  generateRandomCoupon,
  checkIfCouponExist,
};
