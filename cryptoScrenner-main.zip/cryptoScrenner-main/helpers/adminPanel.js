const mysql = require("../mysql");
require("dotenv").config()


const fetchTotalNumUsers = () => {
    return new Promise((resolve,reject) => {
            mysql.query("SELECT count(*) as numUsers FROM users",function(err,results,fields){
                if(err) {console.log(err); return reject(err)}
                return resolve(results[0]);
            })
    })
}

const fetchTotalNumPayedUsers = () => {
    return new Promise((resolve,reject) => {
        mysql.query("SELECT count(user_id) as numPayedUsers FROM users_subscriptions",function(err,results,fields){
            if(err) {console.log(err); return reject(err)}
            return resolve(results[0]);
        })
})
}
const fetchTotalNumUsersToday = () => {
    return new Promise((resolve,reject) => {
        mysql.query("SELECT COUNT(*) as numTodayUsers FROM `users` WHERE creation_time > DATE_SUB(NOW(), INTERVAL 1 DAY);",function(err,results,fields){
            if(err) {console.log(err); return reject(err)}
            return resolve(results[0]);
        })
    })
}

const fetchTotalRevenue = () => {
    return new Promise((resolve,reject) => {
        mysql.query("SELECT * FROM revenue;",function(err,results,fields){
            if(err) {console.log(err);return reject(err)};
            return resolve(results[0]?.total || 0);
        })
    })
}

const fetchUsersWithMembership = () => {
    return new Promise((resolve,reject) => {
        mysql.query("SELECT users.username FROM users JOIN users_subscriptions ON users.id = users_subscriptions.user_id ORDER BY  users_subscriptions.subscription_start_date LIMIT 5;",(err,results,fields) => {
            if(err) {console.log(err);return reject(err)};
            return resolve(results);
        })
    })
}

const fetchAllUsers = () => {
    return new Promise((resolve,reject) => {
        mysql.query("SELECT users.*, CASE WHEN COUNT(users_subscriptions.user_id) > 0 THEN 1 ELSE 0 END AS has_subscription FROM users LEFT JOIN users_subscriptions ON users.id = users_subscriptions.user_id GROUP BY users.id;",(err,results,fields) => {
            if(err) {console.log(err);return reject(err)};
            return resolve(results);
        }
        )
    })
}
const fetchAllMasterCoupons = () => {
    return new Promise((resolve,reject) => {
        mysql.query("SELECT * FROM master_coupon;",(err,results,fields) => {
            if(err) {console.log(err);return reject(err)};
            return resolve(results);
        }
        )
    })
}
const returnAllMasterCoupons = async () => {
    try{
        const results = await fetchAllMasterCoupons();
        return results;
    }catch(err){
        console.log(err);
        return null;
    }
}
const returnTotalNumUser = async () => {
    try {
        const results = await fetchTotalNumUsers();
        return results;
    } catch (err) {
        console.log(err);
        // Puedes manejar el error como desees, incluso devolver un valor por defecto si lo prefieres
        return null; // Por ejemplo, podrías devolver null si hay un error
    }
};

const returnTotalNumPayedUser = async () => {
    try {
        const results = await fetchTotalNumPayedUsers();
        return results;
    } catch (err) {
        console.log(err);
        // Puedes manejar el error como desees, incluso devolver un valor por defecto si lo prefieres
        return null; // Por ejemplo, podrías devolver null si hay un error
    }
}
const returnTotalNumUsersToday = async () =>{
    try{
        const results = await fetchTotalNumUsersToday()
        return results;
    }catch(err){
        console.log(err)
        return null;
    }
}

const returnTotalRevenue = async () => {
    try{
        const results = await fetchTotalRevenue()
        return results;
    }catch(err){
        console.log(err)
        return null;
    }
}
const returnUsersWithMembership = async () => {
    try{
        const results = await fetchUsersWithMembership()
        return results;
    }catch(err){
        console.log(err)
        return null;
    }
}
const returnAllUsers = async () => {
    try{
        const results = await fetchAllUsers()
        return results;
    }catch(err){
        console.log(err)
        return null;
    }
}
module.exports = {
    returnTotalNumUser,
    returnTotalNumPayedUser,
    returnTotalNumUsersToday,
    returnTotalRevenue,
    returnUsersWithMembership,
    returnAllUsers,
    returnAllMasterCoupons
}