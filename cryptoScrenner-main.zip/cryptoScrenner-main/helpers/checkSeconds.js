module.exports = function checkSeconds(seconds,res) {
  if (
    3600 !== seconds &&
    seconds !== 60 &&
    seconds !== 300 &&
    seconds !== 600 &&
    seconds !== 900 &&
    !seconds
  ) {
    return true
  }else{
    return false
  }
};
