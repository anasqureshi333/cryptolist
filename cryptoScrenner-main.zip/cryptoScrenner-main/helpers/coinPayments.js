const mysql = require("../mysql");
require("dotenv").config();
function insertIntoDbIpn({
  ipn_id,
  currency2,
  item_name,
  email,
  status,
  status_text,
  custom,
  amount1,
  txn_id,
}) {
  if (status == 100 || status == 2) {
    mysql.query(
      "SELECT amount FROM coinpayments_ipn WHERE id = ?",
      [txn_id],
      (err, result) => {
        if (err) throw err;
        const amount = result[0].amount;
        mysql.query(
          "UPDATE revenue SET total = total + ?",
          [amount],
          (err, result) => {
            if (err) throw err;
            console.log("1 record inserted or updated");
          }
        );
      }
    );
    mysql.query(
      "SELECT used_coupon FROM users_discount WHERE user_id = (SELECT id FROM users WHERE username = ?)",
      [custom],
      (err, result) => {
        if (err) throw err;
        const amountToPayout =
          item_name === "Monthly Subscription"
            ? 5
            : item_name === "3 Months Subscription"
            ? 10
            : 15;
        if (result.length > 0) {
          mysql.query(
            "INSERT INTO payouts (amount,user_id,refered_user) VALUES (?, (SELECT generated_by_user FROM coupons_generated WHERE coupon=?), (SELECT id FROM users WHERE username = ?))",
            [amountToPayout, result[0].used_coupon, custom],
            (err, results, fields) => {
              if (err) {
                console.log(err);
              }
              console.log("1 record inserted payouts");
              resolve();
            }
          );
        } else {
          console.log("No results found", result);
        }
      }
    );
    switch (item_name) {
      case "Monthly Subscription":
        const fechaActual = new Date();
        fechaActual.setMonth(fechaActual.getMonth() + 1);
        const fechaUnMesAdelante = fechaActual.toISOString().slice(0, 10);
        mysql.query(
          "INSERT INTO users_subscriptions (user_id, subscription_id, subscription_start_date, coin_ipn, end_date) VALUES ((SELECT id FROM users WHERE username = ?), ?, ?, ?, ?) ON DUPLICATE KEY UPDATE subscription_id = VALUES(subscription_id), subscription_start_date = VALUES(subscription_start_date), end_date = VALUES(end_date)",
          [
            custom,
            1,
            new Date().toISOString().slice(0, 10),
            txn_id,
            fechaUnMesAdelante,
          ],
          (err, result) => {
            if (err) throw err;
            console.log(
              "1 record inserted or updated for Monthly Subscription"
            );
          }
        );
        break;
      case "3 Months Subscription":
        const fechaActual3Meses = new Date();
        fechaActual3Meses.setMonth(fechaActual3Meses.getMonth() + 3);
        const fechaTresMesesAdelante = fechaActual3Meses
          .toISOString()
          .slice(0, 10);
        mysql.query(
          "INSERT INTO users_subscriptions (user_id, subscription_id, subscription_start_date, coin_ipn, end_date) VALUES ((SELECT id FROM users WHERE username = ?), ?, ?, ?, ?) ON DUPLICATE KEY UPDATE subscription_id = VALUES(subscription_id), subscription_start_date = VALUES(subscription_start_date), end_date = VALUES(end_date)",
          [
            custom,
            2,
            new Date().toISOString().slice(0, 10),
            txn_id,
            fechaTresMesesAdelante,
          ],
          (err, result) => {
            if (err) throw err;
            console.log(
              "1 record inserted or updated for 3 months subscription"
            );
          }
        );
        break;

      case "6 Months Subscription":
        const fechaActual6Meses = new Date();
        fechaActual6Meses.setMonth(fechaActual6Meses.getMonth() + 6);
        const fechaSeisMesesAdelante = fechaActual6Meses
          .toISOString()
          .slice(0, 10);
        mysql.query(
          "INSERT INTO users_subscriptions (user_id, subscription_id, subscription_start_date, coin_ipn, end_date) VALUES ((SELECT id FROM users WHERE username = ?), ?, ?, ?, ?) ON DUPLICATE KEY UPDATE subscription_id = VALUES(subscription_id), subscription_start_date = VALUES(subscription_start_date), end_date = VALUES(end_date)",
          [
            custom,
            3,
            new Date().toISOString().slice(0, 10),
            txn_id,
            fechaSeisMesesAdelante,
          ],
          (err, result) => {
            if (err) throw err;
            console.log(
              "1 record inserted or updated for 6 months subscription"
            );
          }
        );
        break;
    }
  }
  const query = `
  INSERT INTO coinpayments_ipn (id, ipn_id, currency, item_name, email, status, status_text, username, amount)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  ON DUPLICATE KEY UPDATE
      ipn_id = VALUES(ipn_id),
      currency = VALUES(currency),
      item_name = VALUES(item_name),
      email = VALUES(email),
      status = VALUES(status),
      status_text = VALUES(status_text),
      username = VALUES(username),
      amount = VALUES(amount);
  `;
  const values = [
    txn_id,
    ipn_id,
    currency2,
    item_name,
    email,
    status,
    status_text,
    custom,
    amount1,
  ];
  mysql.query(query, values, (err, result) => {
    if (err) throw err;
    console.log("1 record inserted or updated");
  });
}

function getCoinPaymentsTransactions() {
  return new Promise((resolve, reject) => {
    mysql.query("SELECT * FROM coinpayments_ipn", (err, results, fields) => {
      if (err) return reject(err);
      if (results.length === 0) return reject("No transactions found");
      return resolve(results);
    });
  });
}

async function returnCoinPaymentsTransactions() {
  try {
    const results = await getCoinPaymentsTransactions();
    return results;
  } catch (err) {
    console.log(err);
    return null;
  }
}
module.exports = { insertIntoDbIpn, returnCoinPaymentsTransactions };
