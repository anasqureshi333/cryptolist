const mysql = require("../mysql");
require("dotenv").config();

const fetchLoginHistory = (id) => {
  return new Promise((resolve, reject) => {
    mysql.query(
      "SELECT ip,logged_at FROM login_history WHERE username = (SELECT username FROM users WHERE id = ?) ORDER BY logged_at DESC LIMIT 5;",
      [id],
      (err, results, fields) => {
        if (err) {
          console.log(err);
          return reject(err);
        }
        return resolve(results);
      }
    );
  });
};

const fetchAllUserTransactionsStipe = (id) => {
  return new Promise((resolve, reject) => {
    mysql.query(
      "SELECT * FROM stripe_transactions WHERE customer_username = (SELECT username FROM users WHERE id = ?);",
      [id],
      (err, results, fields) => {
        if (err) {
          console.log(err);
          return reject(err);
        }
        return resolve(results);
      }
    );
  });
};

const fetchAllUserTransactionsCoinpayments = (id) => {
  return new Promise((resolve, reject) => {
    mysql.query(
      "SELECT * FROM coinpayments_ipn WHERE username = (SELECT username FROM users WHERE id = ?);",
      [id],
      (err, results, fields) => {
        if (err) {
          console.log(err);
          return reject(err);
        }
        return resolve(results);
      }
    );
  });
};

const fetchUserDiscount = (id) => {
  return new Promise((resolve, reject) => {
    mysql.query(
      "SELECT * FROM users_discount WHERE user_id = ?",
      [id],
      (err, results, fields) => {
        if (err) {
          console.log(err);
          return reject(err);
        }

        return resolve(results);
      }
    );
  });
};

const fetchCouponGenerated = (id) => {
  return new Promise((resolve, reject) => {
    mysql.query(
      "SELECT * FROM coupons_generated WHERE generated_by_user = ?",
      [id],
      (err, results, fields) => {
        if (err) {
          console.log(err);
          return reject(err);
        }
        if(results.length > 0){
          return resolve(results);
        }else{
          return resolve(results.length > 0);
        }
        
      }
    );
  });
};

const fetchUserReferrals = (id) => {
  return new Promise((resolve,reject) => {
    mysql.query("SELECT coupon FROM coupons_generated WHERE generated_by_user	= ?",[id],(err,results,fields) => {
      if(err){
        console.log(err)
        return reject(err);
      }
      if(results.length > 0){
        mysql.query("SELECT user_id FROM users_discount WHERE used_coupon	= ?",[results[0].coupon],(err,usersUsedCoupon,fields) => {
          if(err){
            console.log(err)
            return reject(err);
          }
          if(usersUsedCoupon.length > 0){
            return resolve(usersUsedCoupon)
          }else{
            return resolve(results.length > 0)
          }
        })
      }else{
        return resolve(results.length > 0)
      }
    })
  })
}


const fetchPayouts = () => {
  return new Promise((resolve,reject) => {
    mysql.query("SELECT payouts.id, payouts.state, payouts.amount, referente.username AS referente_username,  referido.username AS referido_username FROM payouts JOIN users AS referente ON payouts.user_id = referente.id JOIN users AS referido ON payouts.refered_user = referido.id;",(err,results,fields) => {
      if(err){
        console.log(err)
        return reject(err)
      }
      if(results.length > 0){
        resolve(results)
      }else{
        resolve(results > 0)
      }
    })
  })
}
const fetchIfUserHasMasterCoupon = (id) => {
  return new Promise((resolve,reject) => {
    mysql.query("SELECT master_discount FROM users_discount WHERE user_id = ?",[id],(error,results,fields) => {
      if(error){
        console.log(error)
        return reject(error)
      }
      if(results.length > 0){
       
        return resolve(parseInt(results[0].master_discount) === 1)
      }else{
        return resolve(results > 0)
      }
    })
  })
}


const fetchUserPayouts = (id) => {
  return new Promise((resolve,reject) => {
    mysql.query("SELECT * FROM payouts WHERE user_id = ?",[id],(err,results,fields) => {
      if(err){
        console.log(err)
        return reject(err)
      }
      if(results.length > 0){
        resolve(results)
      }else{
        resolve(results > 0)
      }
    })
  })
}

const returnUserPayouts =  async(id) => {
  try{
    const results = await fetchUserPayouts(id)
    return results;
  }catch(err){
    console.log(err)
    return false;
  }
}

const returnFetchIfUserHasMasterDiscount = async (id) => {
  try{
    const results = await fetchIfUserHasMasterCoupon(id)
    return results;
  }catch(err){
    console.log(err)
    return false;
  }
}
const returnPayouts = async () => {
  try{
    const results = await fetchPayouts()
    return results;
  }catch(err){
    console.log(err)
    return false;
  }
}
const returnFetchUserReferrals = async () => {
  try{
    const results = await fetchUserReferrals()
    return results;
  }catch(err){
    console.log(err)
    return false;
  }
}



const returnCouponGenerated = async (id) => {
  try {
    const results = await fetchCouponGenerated(id);
    if (results.length === 0) {
      return false;
    }
    return results;
  } catch (err) {
    console.log(err);
    return false;
  }
};
const returnUserDiscount = async (id) => {
  try {
    const results = await fetchUserDiscount(id);
    if (results.length === 0) {
      return false;
    }
    return results;
  } catch (err) {
    console.log(err);
    return false;
  }
};
const returnAllUserTransactionsCoinpayments = async (id) => {
  try {
    const results = await fetchAllUserTransactionsCoinpayments(id);
    if (results.length === 0) {
      return false;
    }
    return results;
  } catch (err) {
    console.log(err);
    return false;
  }
};
const returnAllUserTransactionsStipe = async (id) => {
  try {
    const results = await fetchAllUserTransactionsStipe(id);
    if (results.length === 0) {
      return false;
    }
    return results;
  } catch (err) {
    console.log(err);
    return false;
  }
};
const returnLoginHistory = async (id) => {
  try {
    const results = await fetchLoginHistory(id);
    if (results.length === 0) {
      return false;
    }
    return results;
  } catch (err) {
    console.log(err);
    return false;
  }
};

module.exports = {
  returnLoginHistory,
  returnAllUserTransactionsStipe,
  returnAllUserTransactionsCoinpayments,
  returnUserDiscount,
  returnCouponGenerated,
  returnFetchUserReferrals,
  returnPayouts,
  returnFetchIfUserHasMasterDiscount,
  returnUserPayouts
};
