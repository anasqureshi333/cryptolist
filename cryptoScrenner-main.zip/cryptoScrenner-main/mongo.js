const mongoose = require('mongoose');

const cryptoSchema = new mongoose.Schema({
  timestamp: { type: Date, expires: 3600 },
  symbol: String,
  price: Number,
  price24h: Number,
  vol24: Number,
});

const Spot = mongoose.model('Spot', cryptoSchema, 'spot');
const Futures = mongoose.model('Futures', cryptoSchema, 'futures');


module.exports = {
    Spot,
    Futures
}