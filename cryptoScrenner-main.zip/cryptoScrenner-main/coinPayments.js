const mysql = require("./mysql");
require("dotenv").config()


const removeExpiredSubscriptions = () => {
    const query = "SELECT * FROM users_subscriptions WHERE coin_ipn IS NOT NULL AND end_date < NOW();";
    mysql.query(query, (err, rows) => {
        if(err){
            return console.log(err);
        }
        rows.forEach(row => {
            mysql.query("DELETE FROM users_subscriptions WHERE users_subscriptions_id = ?", [row.users_subscriptions_id], (err) => {
                if(err){
                    return console.log(err);
                }
                console.log("Subscription removed")
            })
        }
        )
    })
}


setInterval(removeExpiredSubscriptions, 1000 * 60 * 60 * 24);