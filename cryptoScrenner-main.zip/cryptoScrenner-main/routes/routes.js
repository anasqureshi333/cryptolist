const express = require("express");
const router = express.Router();
const validator = require("email-validator");
const {
  getTop10Winners,
  getTop10Losers,
  getTop10VolGainers,
} = require("../binance/futuresFunctions");

const spotFunctions = require("../binance/spotFunctions");
const checkSeconds = require("../helpers/checkSeconds");
const mysql = require("../mysql");
const bcrypt = require("bcrypt");
const uuid = require("uuid");
const rateLimit = require("express-rate-limit");
const jwt = require("jsonwebtoken");
const stripe = require("stripe")(process.env.STRIPE_KEY);
const {
  sendVerifyEmail,
  sendPasswordRecovery,
  newContactFormMessage,
  userRequestedPayout,
} = require("../nodemailer/nodemailer");
const authenticateUser = require("../helpers/authAdmin");
const {
  insertIntoTransactions,
  insertIntoSubscriptions,
  insertIntoStripeSubscriptions,
  updateCustomerSubscription,
  removeCustomerSubscription,
  removeCustomerSubscriptionManually,
  getLatestTransactions,
  tellCustomerToPay,
  returnInsertIntoPayouts,
  fetchAllStripTransaction
} = require("../helpers/stripe");
const {
  checkTokenPOST,
  checkTokenGET,
  checkTokenGETAndUserPremium,
  checkTokenPostAndUserPremium,
} = require("../helpers/checkToken");
const {
  returnTotalNumUser,
  returnTotalNumPayedUser,
  returnTotalNumUsersToday,
  returnTotalRevenue,
  returnUsersWithMembership,
  returnAllUsers,
  returnAllMasterCoupons,
} = require("../helpers/adminPanel");
const path = require("path");
const {
  generateNewCoupon,
  checkIfRefferalExistAndSendCoupon,
  checkIfRefferalExistAndAddCoupon,
  generateRandomCoupon,
  checkIfCouponExist,
} = require("../helpers/referrals");
const {
  insertIntoDbIpn,
  returnCoinPaymentsTransactions,
} = require("../helpers/coinPayments");

const {
  returnLoginHistory,
  returnAllUserTransactionsStipe,
  returnAllUserTransactionsCoinpayments,
  returnUserDiscount,
  returnCouponGenerated,
  returnFetchUserReferrals,
  returnFetchIfUserHasMasterDiscount,
  returnUserPayouts,
  returnPayouts,
} = require("../helpers/userAdmin");

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutos
  max: 99999, // Límite de solicitudes
});
const multer = require("multer");

const upload = multer({ dest: "uploads/" });

var SibApiV3Sdk = require("sib-api-v3-sdk");

// Configure API key authorization: api-key

/* 

   ############################################################# 
   #                                                           #
   #                  SPOT & FUTURES API ROUTES                #  
   #                                                           #
   ############################################################# 
   
*/

const validateSeconds = (seconds) => {
  return isNaN(seconds) || ![60, 300, 600, 900, 3600].includes(Number(seconds));
};

const handleRequest = async (req, res, handler) => {
  const seconds = parseInt(req.query.seconds);
  if (validateSeconds(seconds)) {
    return res.status(400).json({ error: "Invalid seconds parameter" });
  }

  try {
    return res.status(200).json(await handler(seconds));
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: "An error occurred" });
  }
};

router.get("/futures/gainers", checkTokenGETAndUserPremium, (req, res) =>
  handleRequest(req, res, getTop10Winners)
);
router.get("/futures/losers", checkTokenGETAndUserPremium, (req, res) =>
  handleRequest(req, res, getTop10Losers)
);
router.get("/futures/volgainers", checkTokenGETAndUserPremium, (req, res) =>
  handleRequest(req, res, getTop10VolGainers)
);
router.get("/spot/gainers", checkTokenGETAndUserPremium, (req, res) =>
  handleRequest(req, res, spotFunctions.getTop10Winners)
);
router.get("/spot/losers", checkTokenGETAndUserPremium, (req, res) =>
  handleRequest(req, res, spotFunctions.getTop10Losers)
);
router.get("/spot/volgainers", checkTokenGETAndUserPremium, (req, res) =>
  handleRequest(req, res, spotFunctions.getTop10VolGainers)
);

/* 

   ############################################################# 
   #                                                           #
   #                  REGISTRATION API ROUTES                  #  
   #                                                           #
   ############################################################# 
   
*/

router.post("/api/register", function (req, res) {
  const saltRounds = 10;
  const userUuid = uuid.v4();
  const data = req.body;

  if (!data.email || !data.password || !data.username) {
    return res.status(400).send({ msg: "Missing Information" });
  }
  if (!validator.validate(data.email)) {
    return res.status(400).send({ msg: "That is not a valid email" });
  }

  mysql.query(
    "SELECT * FROM users WHERE email = ?",
    [data.email],
    function (err, results, fields) {
      if (err)
        return res.status(500).send({ msg: "500 INTERNAL SERVER ERROR" });
      if (results.length !== 0) {
        return res.status(409).send({ msg: "The email is already taken" });
      }

      mysql.query(
        "SELECT * FROM users WHERE username = ?",
        [data.username],
        function (err, results, fields) {
          if (err)
            return res.status(500).send({ msg: "500 INTERNAL SERVER ERROR" });
          if (results.length !== 0)
            return res
              .status(409)
              .send({ msg: "The username is already taken" });
          var defaultClient = SibApiV3Sdk.ApiClient.instance;

          var apiKey = defaultClient.authentications["api-key"];
          apiKey.apiKey =
            "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";
          var apiInstance = new SibApiV3Sdk.TransactionalEmailsApi();

          var sendSmtpEmail = new SibApiV3Sdk.SendSmtpEmail();
          sendSmtpEmail.to = [
            {
              email: data.email,
              name: data.username,
            },
          ];
          sendSmtpEmail.sender = {
            email: "noreply@quick10x.com",
            name: "Quick10x",
          }; 
          sendSmtpEmail.subject = "Verify Your Quick10x Account"
          sendSmtpEmail.htmlContent = `<p>Hello, thanks for sign up in Quick10x, please verify your account clicking on the following link: <link href='
            https://quick10x.com/verify-email?uuid=${userUuid}'>https://quick10x.com/verify-email?uuid=${userUuid}</link></p>`;
          apiInstance.sendTransacEmail(sendSmtpEmail).then(
            function (data) {
              console.log("API called successfully. Returned data: " + data);
            },
            function (error) {
              console.error(error);
            }
          );

          bcrypt.hash(data.password, saltRounds, function (err, hashPass) {
            if (err)
              return res.status(500).send({ msg: "500 INTERNAL SERVER ERROR" });

            mysql.query(
              "INSERT INTO users (email, password, username, uuid) VALUES (?, ?, ?, ?)",
              [data.email, hashPass, data.username, userUuid],
              function (err, results, fields) {
                if (err)
                  return res.status(500).send("500 INTERNAL SERVER ERROR");

                if (data.discount) {
                  checkIfRefferalExistAndAddCoupon(
                    data.discount,
                    data.username,
                    stripe
                  );
                }

                return res.status(200).send({ msg: "200 OK" });
              }
            );
          });
        }
      );
    }
  );
});

/*verify user email */

router.get("/verify-email", limiter, (req, res) => {
  var userUuid = req.query.uuid;
  if (!uuid.validate(userUuid)) {
    return res.redirect(
      301,
      process.env.ALLOW_DOMAIN + "/sign-in?status=invalid-uuid"
    );
  }
  if (!userUuid) return res.status(400).send({ msg: "400 BAD REQUEST" });
  mysql.query(
    "UPDATE users SET is_loggeable = true WHERE uuid = ? ",
    [userUuid],
    function (error, results, fields) {
      if (error) {
        console.log(error);
        return res.status(500).send({ msg: "500 INTERNAL SERVER ERROR" });
      } else {
        mysql.query(
          "UPDATE users SET uuid = null WHERE uuid = ? ",
          [userUuid],
          function (error, results, fields) {
            if (error) {
              console.log(error);
              return res.status(500).send({ msg: "500 INTERNAL SERVER ERROR" });
            } else {
              return res.redirect(
                301,
                process.env.ALLOW_DOMAIN + "/sign-in?status=verified"
              );
            }
          }
        );
      }
    }
  );
});

router.post("/check-user", async (req, res) => {
  const { data, type } = req.body;
  if (type === "email" && validator.validate(data)) {
    mysql.query(
      "SELECT * FROM users WHERE email = ?",
      [data],
      function (err, results, fields) {
        if (err) console.log(err);
        if (err)
          return res.status(500).send({ msg: "500 INTERNAL SERVER ERROR" });
        if (results.length !== 0) {
          return res.status(409).send({ msg: "The email is already taken" });
        } else {
          res.status(200).send({ msg: "200 OK" });
        }
      }
    );
  } else if (type === "username" && !validator.validate(data)) {
    mysql.query(
      "SELECT * FROM users WHERE username = ?",
      [data],
      function (err, results, fields) {
        if (err)
          return res.status(500).send({ msg: "500 INTERNAL SERVER ERROR" });
        if (results.length !== 0)
          return res.status(409).send({ msg: "The username is already taken" });
        return res.status(200).send({ msg: "200 OK" });
      }
    );
  } else {
    return res.status(400).send({ msg: "400 BAD REQUEST" });
  }
});

/* 

   ############################################################# 
   #                                                           #
   #               LOGIN API ROUTES && AUTH                    #  
   #                                                           #
   ############################################################# 
   
*/

router.post("/api/login", limiter, (req, res) => {
  const data = req.body;
  if (!data.email || !data.password)
    return res.status(400).send({ msg: "Missing Email or Password" });
  mysql.query(
    "SELECT username, password,is_loggeable FROM users WHERE email = ?",
    [data.email],
    async function (error, results, fields) {
      if (error)
        return res.status(500).send({ msg: "500 INTERNAL SERVER ERROR" });
      if (results.length === 0)
        return res
          .status(404)
          .send({ msg: "There is no user with such email" });
      if (parseInt(results[0].is_loggeable) === 0)
        return res.status(401).send({ msg: "You have to verify your email" });
      const validPassword = await bcrypt.compare(
        data.password,
        results[0].password
      );

      if (!validPassword) {
        return res.status(401).send({ msg: "Incorrect Password" });
      }

      const username = results[0].username;

      const token = jwt.sign(
        { email: data.email, username },
        process.env.SECRET_JWT,
        { expiresIn: "7d" }
      );
      mysql.query(
        "INSERT INTO login_history (ip,username) VALUES (?,?)",
        [data.ip || 0, username],
        function (err, results, fields) {
          if (err) console.log(err);
        }
      );
      res.json({ token, username, msg: "Authentication successful" });
    }
  );
});

router.post("/api/auth", limiter, checkTokenPOST, (req, res) => {
  return res.status(200).json({ msg: "200 OK" });
});

/* 

   ############################################################# 
   #                                                           #
   #               STRIPE PAYMENT INTEGRATION                  #  
   #                                                           #
   ############################################################# 
   
*/

router.get("/stripe", async (req, res) => {
  try {
    const { subscriptionId, username, stripeCode, token } = req.query;
    const discount = req.query.discount || null;

    if (!token) {
      return res.redirect(
        401,
        process.env.ALLOW_DOMAIN + "?error=Missing-Token"
      );
    }

    jwt.verify(token, process.env.SECRET_JWT, (err, user) => {
      if (err)
        return res.redirect(403, process.env.ALLOW_DOMAIN + "?error=Forbidden");
    });

    if (!username || !subscriptionId || !stripeCode) {
      return res.redirect(400, process.env.ALLOW_DOMAIN + "?error=Bad-Request");
    }
    if (discount) {
      const query =
        discount === "35.00"
          ? "SELECT stripe_coupon_5 as stripe_coupon,used_coupon FROM users_discount WHERE user_id = (SELECT id FROM users WHERE username = ?)"
          : discount === "90.00"
          ? "SELECT stripe_coupon_10 as stripe_coupon,used_coupon FROM users_discount WHERE user_id = (SELECT id FROM users WHERE username = ?)"
          : "SELECT stripe_coupon_15 as stripe_coupon,used_coupon FROM users_discount WHERE user_id = (SELECT id FROM users WHERE username = ?)";
      mysql.query(query, [username], (err, results, fields) => {
        if (err) {
          console.log(err);
          return res.redirect(
            500,
            process.env.ALLOW_DOMAIN + "?error=Internal-Server-Error"
          );
        }
        const stripeCoupon = results[0].stripe_coupon || null;
        const usedCoupon = results[0].used_coupon || null;
        stripe.checkout.sessions
          .create({
            mode: "subscription",
            line_items: [
              {
                price: stripeCode,
                // For metered billing, do not pass quantity
                quantity: 1,
              },
            ],
            discounts: [
              {
                coupon: stripeCoupon,
              },
            ],
            success_url:
              process.env.ALLOW_DOMAIN + "/dashboard/subscription" + "?state=1",
            cancel_url:
              process.env.ALLOW_DOMAIN + "/dashboard/subscription" + "?state=0",
            metadata: {
              username: username,
              plan: subscriptionId,
              usedCoupon: usedCoupon,
            },
          })
          .then((session) => {
            return res.redirect(303, session.url);
          });
      });
    } else {
      stripe.checkout.sessions
        .create({
          mode: "subscription",
          line_items: [
            {
              price: stripeCode,
              // For metered billing, do not pass quantity
              quantity: 1,
            },
          ],
          success_url:
            process.env.ALLOW_DOMAIN + "/dashboard/subscription" + "?state=1",
          cancel_url:
            process.env.ALLOW_DOMAIN + "/dashboard/subscription" + "?state=0",
          metadata: {
            username: username,
            plan: subscriptionId,
          },
        })
        .then((session) => {
          return res.redirect(303, session.url);
        });
    }
  } catch (err) {
    return res.redirect(
      500,
      process.env.ALLOW_DOMAIN + "?error=Internal-Server-Error"
    );
  }
});

router.post("/stripe/cancel-subscription", checkTokenPOST, async (req, res) => {
  const { username } = req.body;
  if (!username) return res.status(400).json({ msg: "MISSING USERNAME" });
  const result = await removeCustomerSubscriptionManually(username, stripe);
  if (result) {
    return res.status(200).json({ msg: "Your Subscription was removed" });
  } else {
    return res.status(500).json({ msg: "500 INTERNAL SERVER ERROR" });
  }
});

const endpointSecret = "whsec_ys6jKdOJC9rvrtV6LFSC1d3O9iLM9kdW";

router.post(
  "/webhook",
  express.raw({ type: "application/json" }),
  async (request, response) => {
    const sig = request.headers["stripe-signature"];

    let event;

    try {
      event = stripe.webhooks.constructEvent(request.body, sig, endpointSecret);
    } catch (err) {
      response.status(400).send(`Webhook Error: ${err.message}`);
      return;
    }
    const dataObject = event.data.object;

    // Handle the event
    switch (event.type) {
      case "checkout.session.completed":
        await insertIntoTransactions(dataObject);
        await insertIntoSubscriptions(dataObject);
        if (dataObject.metadata.usedCoupon) {
          await returnInsertIntoPayouts(dataObject);
        }
        break;
      case "invoice.payment_failed":
        await tellCustomerToPay(dataObject);
        break;
      case "customer.subscription.created":
        await insertIntoStripeSubscriptions(dataObject);
        break;
      case "customer.subscription.updated":
        await updateCustomerSubscription(dataObject);
        break;
      case "customer.subscription.deleted":
        await removeCustomerSubscription(dataObject);
        break;
      default:
    }

    // Return a 200 response to acknowledge receipt of the event
    response.send();
  }
);

/* 

   ############################################################# 
   #                                                           #
   #               COINPAYMENTS INTEGRATION                    #  
   #                                                           #
   ############################################################# 
   

*/

router.get("/coinpayments", checkTokenGET, (req, res) => {
  try {
    const id = uuid.v4();
    const { amount, item_name, username } = req.query;
    return res.render("coinPayments", {
      amount: amount,
      item_name: item_name,
      username: username,
      id,
    });
  } catch (err) {
    return res.redirect(
      500,
      process.env.ALLOW_DOMAIN + "?error=Internal-Server-Error"
    );
  }
});

router.post("/ipn", express.urlencoded({ extended: true }), (req, res) => {
  if (req.body.ipn_type === "button") {
    insertIntoDbIpn(req.body);
  }

  res.sendStatus(200);
});

/* 

   ############################################################# 
   #                                                           #
   #                      USER MANAGMENT                       #  
   #                                                           #
   ############################################################# 
   

*/

router.get("/api/user/get-user-payouts", checkTokenGET, (req, res) => {
  const { username } = req.query;
  mysql.query(
    "SELECT SUM(amount) as payouts,count(*) as num_payouts FROM payouts WHERE user_id = (SELECT id FROM users WHERE username = ?) AND state= 'pending'",
    [username],
    (err, results, fields) => {
      if (err) {
        console.log(err);
        return res.status(500).json({ msg: "500 INTERNAL SERVER ERROR" });
      }
      if (results.length > 0) {
        mysql.query(
          "SELECT count(*) as num_referrals FROM payouts WHERE user_id = (SELECT id FROM users WHERE username = ?)",
          [username],
          (err, results2, fields) => {
            if (err) {
              console.log(err);
              return res.status(500).json({ msg: "500 INTERNAL SERVER ERROR" });
            }
            if (results2.length > 0) {
              return res
                .status(200)
                .json({ msg: "200 OK", data: { results, results2 } });
            } else {
              return res.status(404).json({ msg: "404 NOT FOUND" });
            }
          }
        );
      } else {
        return res.status(404).json({ msg: "404 NOT FOUND" });
      }
    }
  );
});

router.get(
  "/api/user/get-trc20",
  checkTokenGETAndUserPremium,
  limiter,
  (req, res) => {
    const { username } = req.query;
    if (!username) return res.status(400).json({ msg: "MISSING USERNAME" });
    mysql.query(
      "SELECT trc20_address FROM users WHERE username = ?",
      [username],
      (err, results, fields) => {
        if (err) {
          console.log(err);
          return res.status(500).json({ msg: "500 INTERNAL SERVER ERROR" });
        }
        if (results.length > 0) {
          return res
            .status(200)
            .json({ msg: "200 OK", data: results[0].trc20_address });
        } else {
          return res
            .status(404)
            .json({ msg: "You don't have a TRC20 address yet" });
        }
      }
    );
  }
);

router.post(
  "/api/user/add-trc20",
  checkTokenPostAndUserPremium,
  limiter,
  (req, res) => {
    const { username, trc20 } = req.body;
    if (!username) return res.status(400).json({ msg: "MISSING USERNAME" });
    if (!trc20) return res.status(400).json({ msg: "MISSING TRC20" });
    mysql.query(
      "UPDATE users SET trc20_address = ? WHERE username = ?",
      [trc20, username],
      (err, results, fields) => {
        if (err) {
          console.log(err);
          return res.status(500).json({ msg: "500 INTERNAL SERVER ERROR" });
        }
        return res.status(200).json({ msg: "200 OK" });
      }
    );
  }
);

router.post("/api/user/user-details", checkTokenPOST, limiter, (req, res) => {
  const { username } = req.body;
  if (!username) return res.status(400).json({ msg: "MISSING USERNAME" });
  mysql.query(
    "SELECT email,trc20_address,creation_time,username FROM users WHERE username = ?",
    [username],
    (err, results, fields) => {
      if (err) {
        console.log(err);
        return res.status(500).json({ msg: "500 INTERNAL SERVER ERROR" });
      }
      if (results.length > 0) {
        return res.status(200).json({ msg: "200 OK", data: results[0] });
      } else {
        return res.status(404).json({ msg: "404 NOT FOUND" });
      }
    }
  );
});

router.post(
  "/api/user/change-password",
  checkTokenPOST,
  limiter,
  (req, res) => {
    const { username } = req.body;
    const { newPassword, oldPassword, confirmPassword } = JSON.parse(
      req.body.formData
    );
    if (!oldPassword)
      return res.status(400).json({ msg: "MISSING OLD PASSWORD" });
    if (!newPassword)
      return res.status(400).json({ msg: "MISSING NEW PASSWORD" });
    if (!confirmPassword)
      return res.status(400).json({ msg: "MISSING CONFIRM PASSWORD" });
    if (newPassword !== confirmPassword)
      return res.status(400).json({ msg: "PASSWORDS DO NOT MATCH" });
    if (!username) return res.status(400).json({ msg: "MISSING USERNAME" });
    if (!newPassword) return res.status(400).json({ msg: "MISSING PASSWORD" });
    if (newPassword.length < 8)
      return res.status(400).json({ msg: "PASSWORD TOO SHORT" });
    mysql.query(
      "SELECT password FROM users WHERE username = ?",
      [username],
      async (err, results, fields) => {
        if (err) {
          console.log(err);
          return res.status(500).send({ msg: "500 INTERNAL SERVER ERROR" });
        }
        if (results.length > 0) {
          bcrypt.compare(
            newPassword,
            results[0].password,
            async (err, valid) => {
              if (err) {
                console.log(err);
                return res
                  .status(500)
                  .send({ msg: "500 INTERNAL SERVER ERROR" });
              }
              if (valid) {
                return res.status(409).send({ msg: "PASSWORDS ARE THE SAME" });
              } else {
                bcrypt.compare(
                  oldPassword,
                  results[0].password,
                  async (err, valid) => {
                    if (err) {
                      console.log(err);
                      return res.status(500).send({
                        msg: "500 INTERNAL SERVER ERROR",
                      });
                    }
                    if (valid) {
                      const saltRounds = 10;
                      const hashPass = await bcrypt.hash(
                        newPassword,
                        saltRounds
                      );
                      mysql.query(
                        "UPDATE users SET password = ? WHERE username = ?",
                        [hashPass, username],
                        (err, results, fields) => {
                          if (err) {
                            console.log(err);
                            return res.status(500).send({
                              msg: "500 INTERNAL SERVER ERROR",
                            });
                          }
                          return res.status(200).send({ msg: "200 OK" });
                        }
                      );
                    } else {
                      return res
                        .status(401)
                        .send({ msg: "INCORRECT OLD PASSWORD" });
                    }
                  }
                );
              }
            }
          );
        }
      }
    );
  }
);

router.post("/api/user/recover-password", (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(403).send("You need to enter an email");
  const randomText = [
    "A",
    "B",
    "C",
    "D",
    "E",
    "F",
    "G",
    "H",
    "I",
    "J",
    "K",
    "L",
    "M",
    "N",
    "S",
    "T",
    "U",
    "V",
    "W",
    "X",
    "Y",
    "Z",
  ];
  let codeRecovery = [];
  for (let i = 0; i <= 8; i++) {
    if (Math.random() > 0.5) {
      codeRecovery.push(
        randomText[Math.floor(Math.random() * randomText.length - 1)]
      );
    } else {
      codeRecovery.push(Math.floor(Math.random() * 10));
    }
  }
  mysql.query(
    "UPDATE users SET recover_password = ? WHERE email = ?",
    [codeRecovery.join(""), email],
    (err, results, fields) => {
      if (err) {
        console.log(err);
      }
      if (results.affectedRows > 0) {
        sendPasswordRecovery(email, codeRecovery.join(""));
      }
      return res.status(200).send({
        msg: "A code was sent to your email to verify the password change",
      });
    }
  );
});

router.post("/api/user/recover-password/verify", (req, res) => {
  const { code, email, password } = req.body;
  if (!code || !email) {
    return res
      .status(403)
      .json({ msg: "You need to Enter a code and a Email" });
  }
  mysql.query(
    "SELECT recover_password,username FROM users WHERE recover_password = ?",
    [code],
    async (error, results, fields) => {
      if (error) {
        console.log(error);
        return res.status(500).json({ msg: "INTERNAL SERVER ERROR" });
      }
      if (results.length > 0) {
        const saltRounds = 10;
        const hashPass = await bcrypt.hash(password, saltRounds);
        mysql.query(
          "UPDATE users SET password = ? WHERE email = ?",
          [hashPass, email],
          (error, updatedPassword, fields) => {
            if (error) {
              console.log(error);
              return res.status(500).json({ msg: "INTERNAL SERVER ERROR" });
            }

            const token = jwt.sign(
              { email: email, username: results[0].username },
              process.env.SECRET_JWT,
              { expiresIn: "7d" }
            );
            return res.json({
              token,
              username: results[0].username,
              msg: "Authentication successful",
            });
          }
        );
      } else {
        return res.status(401).json({ msg: "INVALID CODE" });
      }
    }
  );
});

router.post("/api/user/contact", upload.single("file"), limiter, (req, res) => {
  const token = JSON.parse(req.body.data);
  console.log(req.body);
  if (!token || !token.token)
    return res.status(401).send({ msg: "Missing Token" });

  jwt.verify(token.token, process.env.SECRET_JWT, (err, user) => {
    if (err) return res.sendStatus(403);
    const { username, email, message, subject } = JSON.parse(req.body.data);
    if (!username) return res.status(400).json({ msg: "MISSING USERNAME" });
    if (!message) return res.status(400).json({ msg: "MISSING MESSAGE" });
    if (!subject) return res.status(400).json({ msg: "MISSING SUBJECT" });
    mysql.query(
      "SELECT email FROM users WHERE username = ?",
      [username],
      (err, results, fields) => {
        if (err) {
          console.log(err);
          return res.status(500).json({ msg: "500 INTERNAL SERVER ERROR" });
        }
        if (results.length > 0) {
          newContactFormMessage(
            email,
            message,
            subject,
            results[0].email,
            username,
            req.file
          );
          return res.status(200).json({ msg: "200 OK" });
        } else {
          return res.status(404).json({ msg: "404 NOT FOUND" });
        }
      }
    );
  });
});

router.post("/request-payout", checkTokenPOST, limiter, (req, res) => {
  const { username } = req.body;
  if (!username) return res.status(400).json({ msg: "MISSING USERNAME" });
  mysql.query(
    "SELECT SUM(amount) as payouts FROM payouts WHERE user_id = (SELECT id FROM users WHERE username = ?) AND state= 'pending'",
    [username],
    (err, results, fields) => {
      if (err) {
        console.log(err);
        return res.status(500).json({ msg: "500 INTERNAL SERVER ERROR" });
      }
      if (results.length > 0) {
        if (results[0].payouts > 0) {
          mysql.query(
            "SELECT trc20_address FROM users WHERE username = ?",
            [username],
            (err, trc20, fields) => {
              if (err) {
                console.log(err);
                return res
                  .status(500)
                  .json({ msg: "500 INTERNAL SERVER ERROR" });
              }
              if (trc20.length > 0 && trc20[0].trc20_address !== null) {
                userRequestedPayout(
                  username,
                  results[0].payouts,
                  trc20[0].trc20_address
                );
                return res.status(200).json({ msg: "Payout Requested" });
              } else {
                return res
                  .status(404)
                  .json({ msg: "You don't have a TRC20 address yet" });
              }
            }
          );
        }
      } else {
        return res
          .status(404)
          .json({ msg: "You don't have any payouts to request" });
      }
    }
  );
});

/* 

   ############################################################# 
   #                                                           #
   #                    GET USERS DISCOUNT                     #  
   #                                                           #
   ############################################################# 
   

*/

router.post("/api/get-user-discount", checkTokenPOST, limiter, (req, res) => {
  const { username } = req.body;
  if (!username) {
    return res.status(400).json({ msg: "MISSING USERNAME" });
  }
  mysql.query(
    "SELECT master_discount FROM users_discount WHERE user_id = (SELECT id FROM users WHERE username = ?)",
    [username],
    (err, results, fields) => {
      if (err) {
        console.log(err);
        return res.status(500).json({ msg: "500 INTERNAL SERVER ERROR" });
      }
      if (results.length > 0) {
        if (results[0].master_discount) {
          return res.status(200).json({
            discount: { monthly: 10, threeMonths: 20, sixMonth: 30 },
            msg: "200 OK",
          });
        } else {
          return res.status(200).json({
            discount: { monthly: 5, threeMonths: 10, sixMonth: 15 },
            msg: "200 OK",
          });
        }
      } else {
        return res.status(404).json({ msg: "404 NOT FOUND" });
      }
    }
  );
});

/* 

   ############################################################# 
   #                                                           #
   #                      REFERRALS ROUTES                     #  
   #                                                           #
   ############################################################# 
   

*/

router.post(
  "/api/referrals/new-coupon",
  checkTokenPOST,
  limiter,
  async (req, res) => {
    const { username } = req.body;
    if (!username) return res.status(400).json({ msg: "MISSING USERNAME" });
    await generateNewCoupon(res, username);
  }
);

router.post("/api/coupon/redeem", checkTokenPOST, limiter, async (req, res) => {
  const { username, coupon } = req.body;
  if (!username) return res.status(400).json({ msg: "MISSING USERNAME" });
  if (!coupon) return res.status(400).json({ msg: "MISSING COUPON" });
  await checkIfRefferalExistAndSendCoupon(res, coupon, username, stripe);
});

router.post(
  "/api/coupon/check-user-coupon",
  checkTokenPOST,
  limiter,
  async (req, res) => {
    const { username } = req.body;
    if (!username) return res.status(400).json({ msg: "MISSING USERNAME" });
    mysql.query(
      "SELECT coupon FROM coupons_generated WHERE generated_by_user = (SELECT id FROM users WHERE username = ?)",
      [username],
      (err, results, fields) => {
        if (err) {
          console.log(err);
          return res.status(500).json({ msg: "500 INTERNAL SERVER ERROR" });
        }
        if (results.length > 0) {
          return res
            .status(200)
            .json({ msg: "200 OK", data: results[0].coupon });
        } else {
          return res.status(404).json({ msg: "404 NOT FOUND" });
        }
      }
    );
  }
);
/* 

   ############################################################# 
   #                                                           #
   #                    SUBSCRIPTION ROUTES                    #  
   #                                                           #
   ############################################################# 
   

*/

router.get("/api/subscriptions/active-subscriptions", (req, res) => {
  mysql.query("SELECT * FROM subscriptions", (err, results, fields) => {
    if (err) {
      console.error(err); // Log del error para que puedas ver los detalles en tus logs
      return res
        .status(500)
        .send({ msg: "500 INTERNAL SERVER ERROR", error: err.message });
    }
    return res.status(200).json({ data: results, msg: "200 OK" }); // Respuesta en formato JSON con todos los resultados
  });
});

router.post("/api/subscriptions/user-subscription", limiter, (req, res) => {
  try {
    const { username, token } = req.body;
    if (!token) return res.status(401).send({ msg: "Missing Token" });

    jwt.verify(token, process.env.SECRET_JWT, (err, user) => {
      if (err) return res.sendStatus(403);
      if (user.username !== username)
        return res.status(401).send({ msg: "Token does not match the user" });
    });

    if (!username) return res.status(400).json({ msg: "MISSING USERNAME" });

    const query = `
      SELECT u.id AS user_id, s.subscription_name, us.subscription_start_date
      FROM users u
      JOIN users_subscriptions us ON u.id = us.user_id
      JOIN subscriptions s ON us.subscription_id = s.subscription_id
      WHERE u.username = ?
    `;

    mysql.query(query, [username], function (err, results) {
      if (err)
        return res.status(500).send({ msg: "500 INTERNAL SERVER ERROR", err });

      if (results.length > 0) {
        res.status(200).json({
          msg: "USER HAS SUBSCRIPTION",
          data: {
            subscription_start_date: results[0].subscription_start_date,
            name: results[0].subscription_name,
          },
        });
      } else {
        res.status(401).json({ msg: "USER DOES NOT HAVE SUBSCRIPTION" });
      }
    });
  } catch (err) {
    console.log("Error:", err);
    return res.status(500).send({ msg: "500 INTERNAL SERVER ERROR" });
  }
});

router.get(
  "/subscription/user-check",
  checkTokenGETAndUserPremium,
  (req, res) => {
    res.status(200).json({ msg: "200 OK" });
  }
);

/* 

   ############################################################# 
   #                                                           #
   #                      ADMIN ROUTES                         #  
   #                                                           #
   ############################################################# 
   

*/

router.get(process.env.ADMIN_ROUTE, (req, res) => {
  try {
    const authHeader = req.headers["authorization"];
    const token =
      req.cookies.token ||
      (authHeader ? authHeader.split(" ")[1] : null) ||
      null;
    if (!token) {
      return res.render("index.ejs");
    }

    jwt.verify(token, process.env.SECRET_JWT_ADMIN, (err, decoded) => {
      if (err) {
        return res.render("index.ejs");
      }

      req.user = decoded;

      return res.redirect("/fredrick/panel");
    });
  } catch (err) {
    console.log(err);
    return res.status(500).json({ message: "AUTORIZATION ERROR" });
  }
});

router.post(
  process.env.ADMIN_ROUTE,
  express.urlencoded({ extended: true }),
  async (req, res) => {
    try {
      const { email, password } = req.body;
      mysql.query(
        "SELECT password FROM special_user WHERE email = ?",
        [email],
        async (err, results, fields) => {
          if (err) res.redirect(500, process.env.ADMIN_ROUTE);
          if (results.length > 0) {
            const isPassword = await bcrypt.compare(
              password,
              results[0].password
            );
            if (isPassword) {
              const token = jwt.sign(
                { email: email },
                process.env.SECRET_JWT_ADMIN,
                {
                  expiresIn: "2h",
                }
              );

              res.cookie("token", token, { httpOnly: true });
              res.redirect(process.env.ADMIN_ROUTE_PANEL);
            } else {
              res.redirect(process.env.ADMIN_ROUTE);
            }
          } else {
            res.redirect(process.env.ADMIN_ROUTE);
          }
        }
      );
    } catch (err) {
      res.redirect(500, process.env.ADMIN_ROUTE);
    }
  }
);
router.get(
  process.env.ADMIN_ROUTE_PANEL,
  authenticateUser,
  async (req, res) => {
    const TotalNumOfUsers = await returnTotalNumUser();
    const totalNumOfPayedUsers = await returnTotalNumPayedUser();
    const totalNumUsersToday = await returnTotalNumUsersToday();
    const totalRevenue = await returnTotalRevenue();
    const usersWithMembership = await returnUsersWithMembership();
    const latestTransactions = (await getLatestTransactions()) || [];
    const allPayouts = (await returnPayouts()) || [];
    const latestCoinPaymentsTransactions =
      (await returnCoinPaymentsTransactions()) || [];
    const masterCoupon = (await returnAllMasterCoupons()) || [];
    res.render("panel", {
      TotalNumOfUsers,
      totalNumOfPayedUsers,
      totalNumUsersToday,
      totalRevenue,
      usersWithMembership,
      latestTransactions,
      latestCoinPaymentsTransactions,
      masterCoupon,
      allPayouts: allPayouts.splice(0, 4),
    });
  }
);
router.get("/fredrick/users", authenticateUser, async (req, res) => {
  const allUsers = await returnAllUsers();
  const userToSearch = req.query.user;
  if (userToSearch) {
    const filteredUsers = allUsers.filter((user) =>
      user.username.toLowerCase().includes(userToSearch.toLowerCase())
    );
    return res.render("users", { allUsers: filteredUsers, userToSearch });
  }
  return res.render("users", { allUsers, userToSearch: false });
});

router.get("/fredrick/users/:id", authenticateUser, async (req, res) => {
  const { id } = req.params;
  const loginHistory = await returnLoginHistory(id);
  const stripeTransactions = await returnAllUserTransactionsStipe(id);
  const coinPaymentsTransactions = await returnAllUserTransactionsCoinpayments(
    id
  );
  const userDiscount = await returnUserDiscount(id);
  const userCouponGenerated = await returnCouponGenerated(id);
  const hasMasterDiscount = await returnFetchIfUserHasMasterDiscount(id);
  const userPayouts = (await returnUserPayouts(id)) || [];
  mysql.query(
    "SELECT * FROM users WHERE id = ?",
    [id],
    async (err, results, fields) => {
      if (err) {
        console.log(err);
        return res.redirect("/fredrick/users");
      }
      if (results.length > 0) {
        return res.render("user", {
          user: results[0],
          loginHistory,
          stripeTransactions,
          coinPaymentsTransactions,
          userDiscount,
          userCouponGenerated,
          userId: id,
          hasMasterDiscount,
          userPayouts,
        });
      } else {
        return res.redirect("/fredrick/users");
      }
    }
  );
});

router.post(
  "/fredrick/panel/generate-master-coupon",
  authenticateUser,
  async (req, res) => {
    let masterCoupon = generateRandomCoupon();
    if (await checkIfCouponExist(masterCoupon)) {
      do {
        masterCoupon = generateRandomCoupon();
      } while (await checkIfCouponExist(masterCoupon));
    }
    mysql.query(
      "INSERT INTO master_coupon (coupon) VALUES (?)",
      [masterCoupon],
      (err, results, fields) => {
        if (err) {
          console.log(err);
          return res.redirect("/fredrick/panel?error=500");
        }
        return res.redirect("/fredrick/panel?success=200");
      }
    );
  }
);
router.get(
  "/fredrick/panel/remove-master-coupon/:id",
  authenticateUser,
  async (req, res) => {
    const { id } = req.params;
    mysql.query(
      "DELETE FROM master_coupon WHERE id = ?",
      [id],
      (err, results, fields) => {
        if (err) {
          console.log(err);
          return res.redirect("/fredrick/panel?error=500");
        }
        return res.redirect("/fredrick/panel?success=200");
      }
    );
  }
);

router.post("/fredrick/logout", authenticateUser, (req, res) => {
  res.clearCookie("token");
  res.redirect(process.env.ADMIN_ROUTE);
});

router.post(
  "/fredrick/users/:id/desactivate-activate",
  authenticateUser,
  (req, res) => {
    const { id } = req.params;
    if (!id) return res.redirect("/fredrick/users/" + id + "?state=error");
    mysql.query(
      "SELECT is_loggeable FROM users WHERE id = ?",
      [id],
      (err, results, fields) => {
        if (err) {
          console.log(err);
          return res.redirect("/fredrick/users/" + id + "?state=500-error");
        }
        if (results.length > 0) {
          if (results[0].is_loggeable === 0) {
            mysql.query(
              "UPDATE users SET is_loggeable = TRUE WHERE id = ?",
              [id],
              (err, isUserLoggeable) => {
                if (err) {
                  console.log(err);
                  return res.redirect(
                    "/fredrick/users/" + id + "?state=500-error"
                  );
                }
                return res.redirect("/fredrick/users/" + id + "?state=200");
              }
            );
          } else {
            mysql.query(
              "UPDATE users SET is_loggeable = FALSE WHERE id = ?",
              [id],
              (err, isNoLongerLoggeable) => {
                if (err) {
                  console.log(err);
                  return res.redirect(
                    "/fredrick/users/" + id + "?state=500-error"
                  );
                }
                return res.redirect("/fredrick/users/" + id + "?state=200");
              }
            );
          }
        } else {
          return res.redirect("/fredrick/users/" + id + "?state=404");
        }
      }
    );
  }
);

router.post(
  "/fredrick/users/:id/add-master-coupon",
  authenticateUser,
  async (req, res) => {
    const { id } = req.params;
    if (!id) return res.redirect("/fredrick/users/" + id + "?state=error");
    const firstCoupon = await stripe.coupons.create({
      duration: "forever",
      id: uuid.v4(),
      amount_off: 1000,
      currency: "USD",
    });
    const secondCoupon = await stripe.coupons.create({
      duration: "forever",
      id: uuid.v4(),
      amount_off: 2000,
      currency: "USD",
    });
    const thirdCoupon = await stripe.coupons.create({
      duration: "forever",
      id: uuid.v4(),
      amount_off: 3000,
      currency: "USD",
    });
    const secondQuery =
      "INSERT INTO users_discount (user_id,stripe_coupon_5,stripe_coupon_10,stripe_coupon_15,master_discount) VALUES (?,?,?,?,?)";
    mysql.query(
      secondQuery,
      [id, firstCoupon.id, secondCoupon.id, thirdCoupon.id, 1],
      (err) => {
        if (err) {
          console.log(err);
          return res.redirect("/fredrick/users/" + id + "?state=500-error");
        }
        return res.redirect("/fredrick/users/" + id + "?state=200");
      }
    );
  }
);

router.get("/fredrick/payouts", async (req, res) => {
  const allPayouts = (await returnPayouts()) || [];

  return res.render("payouts", { allPayouts });
});

router.get(
  "/fredrick/users/:id/switch-payout/:payoutId",
  authenticateUser,
  (req, res) => {
    const { id, payoutId } = req.params;
    if (!id || !payoutId)
      return res.redirect("/fredrick/users/" + id + "?state=200");
    mysql.query(
      "SELECT state FROM payouts WHERE id = ?",
      [payoutId],
      (err, results, fields) => {
        if (err) {
          console.log(err);
          return res.redirect("/fredrick/users/" + id + "?state=500");
        }
        if (results.length > 0) {
          if (results[0].state === "pending") {
            mysql.query(
              "UPDATE payouts SET state = 'paid' WHERE id = ?",
              [payoutId],
              (err, results, fields) => {
                if (err) {
                  console.log(err);
                  return res.redirect("/fredrick/users?error=500");
                }
                return res.redirect("/fredrick/users/" + id + "?state=200");
              }
            );
          } else {
            mysql.query(
              "UPDATE payouts SET state = 'pending' WHERE id = ?",
              [payoutId],
              (err, results, fields) => {
                if (err) {
                  console.log(err);
                  return res.redirect("/fredrick/users?error=500");
                }
                return res.redirect("/fredrick/users/" + id + "?state=200");
              }
            );
          }
        } else {
          return res.redirect("/fredrick/users/" + id + "?state=404");
        }
      }
    );
  }
);

router.get("/fredrick/transactions/stripe", async (req, res) => {
  const latestTransactions = (await fetchAllStripTransaction()) || [];
  return res.render("transactionsStripe", { latestTransactions });
});

router.get("/fredrick/transactions/coinpayments", async (req, res) => {
  const latestCoinPaymentsTransactions =
    (await returnCoinPaymentsTransactions()) || [];
  return res.render("transactionsCoinpayments", {
    latestCoinPaymentsTransactions,
  });
});

module.exports = router;
